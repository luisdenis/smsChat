/*
 * XML Type:  RatingTyp
 * Namespace: http://www.somecorp.com/customer
 * Java type: com.somecorp.customer.RatingTyp
 *
 * Automatically generated - do not modify.
 */
package com.somecorp.customer.impl;
/**
 * An XML RatingTyp(@http://www.somecorp.com/customer).
 *
 * This is an atomic type that is a restriction of com.somecorp.customer.RatingTyp.
 */
public class RatingTypImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements com.somecorp.customer.RatingTyp
{
    private static final long serialVersionUID = 1L;
    
    public RatingTypImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected RatingTypImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
