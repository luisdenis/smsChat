/*
 * XML Type:  CardIssuerTyp
 * Namespace: http://www.somecorp.com/creditcard
 * Java type: com.somecorp.creditcard.CardIssuerTyp
 *
 * Automatically generated - do not modify.
 */
package com.somecorp.creditcard.impl;
/**
 * An XML CardIssuerTyp(@http://www.somecorp.com/creditcard).
 *
 * This is an atomic type that is a restriction of com.somecorp.creditcard.CardIssuerTyp.
 */
public class CardIssuerTypImpl extends org.apache.xmlbeans.impl.values.JavaStringEnumerationHolderEx implements com.somecorp.creditcard.CardIssuerTyp
{
    private static final long serialVersionUID = 1L;
    
    public CardIssuerTypImpl(org.apache.xmlbeans.SchemaType sType)
    {
        super(sType, false);
    }
    
    protected CardIssuerTypImpl(org.apache.xmlbeans.SchemaType sType, boolean b)
    {
        super(sType, b);
    }
}
