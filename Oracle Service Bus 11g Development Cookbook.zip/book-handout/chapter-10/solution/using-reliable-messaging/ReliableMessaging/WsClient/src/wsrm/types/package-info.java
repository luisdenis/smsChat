@javax.xml.bind.annotation.XmlSchema(namespace = "http://wsrm.osbbook")
package wsrm.types;
